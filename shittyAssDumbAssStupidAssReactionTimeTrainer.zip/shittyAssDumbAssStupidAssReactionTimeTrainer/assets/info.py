maxHits = 2
hitBoxSize = 64
backgroundColor = (255, 120, 120)
hitboxColor = (255,255,255)
fontColor = (0,0,0)
playTime = 10
buttonColor = (255,255,255)